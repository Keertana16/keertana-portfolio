# 🚑 RoadSoS Vanguard

![App Icon](docs/screenshots/app_icon.png)

> **A fast, AI-powered emergency response system for road accidents that works offline and saves lives.**

## 📖 What is RoadSoS?

**RoadSoS** is a smart web application designed to help people during road accidents or medical emergencies. In high-pressure situations, people often panic and don't know what to do. RoadSoS solves this by providing:
- **Instant First-Aid Advice:** Powered by Google's Gemini AI, it tells you exactly what to do step-by-step.
- **Nearby Hospitals:** It automatically finds the closest hospitals based on your current location.
- **Offline Reliability:** If you lose internet connection, the app has a built-in offline mode with essential first-aid steps and fallback hospital data so you are never left helpless.
- **Crash Detection:** Uses your phone's sensors to detect sudden stops or impacts.

## ✨ Key Features (Explained Simply)

1. **🏥 Nearby Hospital Finder**
   - *What it does:* Uses your GPS location to find hospitals around you.
   - *How it works:* It talks to OpenStreetMap to get a list of nearby medical centers and shows you how far they are.

2. **🤖 AI Triage (Emergency Medical Assistant)**
   - *What it does:* You type what happened (e.g., "head injury, bleeding"), and it instantly gives you 3 simple, safe, and actionable first-aid steps.
   - *How it works:* It uses Google's Gemini AI under the hood. It even "streams" the words on your screen so you don't have to wait for the whole answer to load.

3. **📶 Works Offline (Zero-Cloud Fallback)**
   - *What it does:* If you are on a highway with no signal, the app still works!
   - *How it works:* It saves crucial medical advice and a backup list of hospitals on your phone so you can access them anywhere.

4. **🚗 Drive Mode (Automated Crash Detection Protocol)**
   - *What it does:* Monitors your phone's movements while driving. If it detects a severe impact (G-force spike), it automatically triggers an emergency protocol.
   - *How it works:* Uses the HTML5 Accelerometer API. It uses a 3-gate fail-safe protocol to ensure accuracy and gives you a 10-second window to cancel before dispatching an SOS.

5. **🚨 Zero-Touch WhatsApp Dispatch**
   - *What it does:* Automatically sends a critical SOS message (with your GPS coordinates and medical ID) to your emergency contact without you having to tap "send".
   - *How it works:* Integrated securely with Twilio's API on the backend to bypass manual WhatsApp app opening when you are incapacitated.

6. **🧠 Smart Hospital Caching**
   - *What it does:* Pre-downloads hospital locations while you have a healthy internet connection while driving.
   - *How it works:* Uses background sync so that if a crash occurs in a total network dead zone, the exact coordinates of the nearest hospitals are already saved locally.

7. **⏱️ Golden Hour Timer**
   - *What it does:* Displays a highly visible countdown timer.
   - *How it works:* Emphasizes the critical 60-minute "Golden Hour" window for trauma patients to reach a hospital, creating a sense of urgency for bystanders.

8. **📱 Emergency Medical ID (QR Code)**
   - *What it does:* Creates a QR code with your blood type and allergies. First responders can scan it to know your medical history instantly.

## 📸 Screenshots

| Landing Page | Emergency Dashboard | AI Triage Result |
| :---: | :---: | :---: |
| <img src="docs/screenshots/01_landing.png" width="250"> | <img src="docs/screenshots/02_emergency_active.png" width="250"> | <img src="docs/screenshots/03_triage_result.png" width="250"> |

## 🚀 How to Run the App (Getting Started)

Running RoadSoS is easy. It uses a **Zero-Cloud Local Architecture** (no reliance on external hosted services other than AI/SMS APIs), meaning you run it locally on your PC.

### Prerequisites
Make sure you have installed:
- [Node.js](https://nodejs.org/) (for the frontend)
- [Python 3](https://www.python.org/) (for the backend)

### 1. Start the Backend (The Brain)
Open a terminal and follow these steps:
```bash
# Go to the backend folder
cd backend

# Install the required Python packages
pip install -r requirements.txt

# Create a .env file from the example
cp .env.example .env 

# Open .env and add your API Keys:
# - GEMINI_API_KEY="your_google_ai_key"
# - TWILIO_ACCOUNT_SID="your_twilio_sid" (Optional)
# - TWILIO_AUTH_TOKEN="your_twilio_token" (Optional)

# Start the backend server
uvicorn main:app --reload
```
*The backend will now run on `http://127.0.0.1:8000`.*

### 2. Start the Frontend (The App)
Open a **new** terminal and follow these steps:
```bash
# Go to the frontend folder
cd frontend

# Install the required Node packages
npm install

# Start the frontend app
npm run dev
```
*The app will now open in your browser at `http://localhost:5173`.*

## 🛠️ Technology Stack

- **Frontend:** React.js (v18), Vite, Tailwind CSS (Styled for a modern, premium tactical HUD)
- **Backend:** Python 3, FastAPI, Uvicorn, HTTPX (Super fast, non-blocking asynchronous SSE streaming)
- **AI Engine:** Google Gemini 2.5 Flash
- **SOS Dispatch:** Twilio WhatsApp API
- **Maps / Location:** OpenStreetMap (Overpass API)
- **PWA (Progressive Web App):** Allows you to install the app on your phone's home screen.

---
*Built with ❤️ for the AI Road Safety Hackathon.*
